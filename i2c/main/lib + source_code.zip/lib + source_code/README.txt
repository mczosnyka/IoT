Plik interface_library_ssd1306.pdf - interfejs, dokumentacja bilbioteki
Plik main.c - przykład działania biblioteki
Plik user_input.c - pomocniczy plik handlujący input użytkownika na monitor (użyty do prezentacji oraz przykładu działania)
Pliki ssd1306.h, ssd1306.c oraz font8x8_basic.h - składają się na bibliotekę do obsługi wyświetlacza 